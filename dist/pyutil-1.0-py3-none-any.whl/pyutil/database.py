import psycopg2

from pyutil import defaults
defaults = defaults.logger

class Database():
    def __init__(self, ):
